#pragma once

int set_security_level(int, int);
int get_security_level(int);
int* retrieve_set_security_params(int, int);
int* retrieve_get_security_params(int);
int interpret_set_security_result(int);
int interpret_get_security_result(int);
