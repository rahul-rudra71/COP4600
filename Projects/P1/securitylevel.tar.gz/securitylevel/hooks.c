#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <stdlib.h>

int set_security_level(int pid, int new_level)
{
        return syscall(336, pid, new_level);
}

int get_security_level(int pid)
{
        return syscall(335, pid);
}

int* retrieve_set_security_params(int pid, int new_level)
{
	int* ptr;
	ptr = (int*) malloc(4 * sizeof(int));
	ptr[0] = 336;
	ptr[1] = 2;
	ptr[2] = pid;
	ptr[3] = new_level;
	return ptr;
}

int* retrieve_get_security_params(int pid)
{
	int* ptr;
	ptr = (int*) malloc(3 * sizeof(int));
        ptr[0] = 335;
	ptr[1] = 1;
        ptr[2] = pid;
        return ptr;
}

int interpret_set_security_result(int ret_value)
{
	return ret_value;
}

int interpret_get_security_result(int ret_value)
{
	return ret_value;
}
