#include <jni.h>
#include <string>
#include "read_file.h"
#include "read_file.cpp"

extern "C"
JNIEXPORT jstring

JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_stringFromJNI(
        JNIEnv *env,
        jobject,
        jstring input /* this */) {
    const char *filename = (*env).GetStringUTFChars(input, 0);
    const char *buff = read_file(filename);
    if (buff == NULL) {
        buff = "Error: File not Found";
    }
    (*env).ReleaseStringUTFChars(input, filename);
    return env->NewStringUTF(buff);
}
