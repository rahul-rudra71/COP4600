//
// Created by rudra on 10/23/2019.
//

#ifndef P2_READ_FILE_H
#define P2_READ_FILE_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string>
#include "read_file.h"

char *read_file(const char *filename) {
    int fd;
    struct stat fileStat;

    fd = open(filename, O_RDONLY);

    if (fstat(fd,&fileStat) == -1) {
        char *buff = NULL;
        return buff;
    }

    char *buff = (char*)malloc(fileStat.st_size + 1);
    buff[fileStat.st_size + 1] = '\0';
    read(fd, buff, fileStat.st_size);

    close(fd);
    printf("%s\n", buff);

    return buff;
}

#endif //P2_READ_FILE_H
