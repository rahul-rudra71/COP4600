#include <libusb.h>
#include <linux/uinput.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>


int fd;

void emit(int fd, int type, int code, int val)
{
    struct input_event ie;
    
    ie.type = type;
    ie.code = code;
    ie.value = val;
    /* timestamp values below are ignored */
    ie.time.tv_sec = 0;
    ie.time.tv_usec = 0;
    
    write(fd, &ie, sizeof(ie));
}

char *getBinary(int x){
	char *bits;
	bits = (char*)malloc(8);
    int check;
    int index = 0;

	for(int a = 7; a >= 0; a--) {
		check = x >> a;
		if (check & 1) {
			*(bits + index) = 1 + '0';
		} else {
			*(bits + index) = 0 + '0';
		}
		index++;
	}
	return bits;
}

void inputDecode(int num) {
    //nothing is pressed
    if (num == 10) {
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, 0);
        emit(fd, EV_ABS, ABS_Y, 0);
        emit(fd, EV_SYN, SYN_REPORT,0);
    //only button
    } else if (num == 26) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, 0);
        emit(fd, EV_ABS, ABS_Y, 0);
        emit(fd, EV_SYN, SYN_REPORT,0);
    //no button left
    } else if (num == 6) {
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, -32767);
        emit(fd, EV_ABS, ABS_Y, 0);
        emit(fd, EV_SYN, SYN_REPORT,0);
    //button left
    } else if (num == 22) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, -32767);
        emit(fd, EV_ABS, ABS_Y, 0);
        emit(fd, EV_SYN, SYN_REPORT,0);
    //no button right
    } else if (num == 14) {
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, 32767);
        emit(fd, EV_ABS, ABS_Y, 0);
        emit(fd, EV_SYN, SYN_REPORT,0);
    } else if (num == 30) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, 32767);
        emit(fd, EV_ABS, ABS_Y, 0);
        emit(fd, EV_SYN, SYN_REPORT,0);
    //no button  up
    } else if (num == 11) { 
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, 0);
        emit(fd, EV_ABS, ABS_Y, -32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //no button up left
    } else if (num == 7) { 
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, -32767);
        emit(fd, EV_ABS, ABS_Y, -32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //no button up right
    } else if (num == 15) { 
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, 32767);
        emit(fd, EV_ABS, ABS_Y, -32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //button  up
    } else if (num == 27) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, 0);
        emit(fd, EV_ABS, ABS_Y, -32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //button up left
    } else if (num == 23) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, -32767);
        emit(fd, EV_ABS, ABS_Y, -32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //button up right
    } else if (num == 31) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, 32767);
        emit(fd, EV_ABS, ABS_Y, -32767);
        emit(fd, EV_SYN, SYN_REPORT,0);
    //no button  down
    } else if (num == 9) { 
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, 0);
        emit(fd, EV_ABS, ABS_Y, 32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //no button down left
    } else if (num == 5) { 
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, -32767);
        emit(fd, EV_ABS, ABS_Y, 32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //no button down right
    } else if (num == 13) { 
        emit(fd, EV_KEY, BTN_0, 0);
        emit(fd, EV_ABS, ABS_X, 32767);
        emit(fd, EV_ABS, ABS_Y, 32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //button  down
    } else if (num == 25) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, 0);
        emit(fd, EV_ABS, ABS_Y, 32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //button down left
    } else if (num == 21) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, -32767);
        emit(fd, EV_ABS, ABS_Y, 32767);
        emit(fd, EV_SYN, SYN_REPORT,0); 
    //button down right
    } else if (num == 29) {
        emit(fd, EV_KEY, BTN_0, 1);
        emit(fd, EV_ABS, ABS_X, 32767);
        emit(fd, EV_ABS, ABS_Y, 32767);
        emit(fd, EV_SYN, SYN_REPORT,0);
    }
}

int main() {
    struct uinput_setup usetup;
    fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    
    ioctl(fd, UI_SET_EVBIT, EV_KEY);
    ioctl(fd, UI_SET_KEYBIT, BTN_0);
    ioctl(fd, UI_SET_EVBIT, EV_ABS);
    ioctl(fd, UI_SET_ABSBIT, ABS_X);
    ioctl(fd, UI_SET_ABSBIT, ABS_Y);

    memset(&usetup, 0, sizeof(usetup));
    usetup.id.bustype = BUS_USB;
    usetup.id.vendor = 0x9A7A; 
    usetup.id.product = 0xBA17; 
    strcpy(usetup.name, "js0");

    ioctl(fd, UI_DEV_SETUP, &usetup);
    ioctl(fd, UI_DEV_CREATE);

    int transfer;
    unsigned char data[1];
    libusb_device_handle* dev_handle;
    libusb_init(NULL);

    dev_handle = libusb_open_device_with_vid_pid(NULL, 0x9A7A, 0xBA17);

    libusb_claim_interface(dev_handle, 0);


    while (1) {
        libusb_interrupt_transfer(dev_handle, 129, data, sizeof(data), &transfer, 1000);
        int usbData = data[0];
        char * p = getBinary(usbData);
        
        int total = 0;
        total = (int)strtol(p,NULL,2);
        inputDecode(total);
    }

    ioctl(fd, UI_DEV_DESTROY);
    close(fd);

    return (0);
}